<?php
  ob_start(); //output buffering is turned on
  
// Assign file paths to PHP constants
define("PRIVATE_PATH", dirname(__FILE__));
define("PROJECT_PATH", dirname(PRIVATE_PATH));
define("SHARED_PATH", PRIVATE_PATH . '/shared');
define("VIEW_PATH", PRIVATE_PATH . '/view');
define("PUBLIC_PATH", PROJECT_PATH . '/public');

// Assign the root URL to a PHP constant
$public_end = strpos($_SERVER['SCRIPT_NAME'], '/public') + 7;
$doc_root = substr($_SERVER['SCRIPT_NAME'], 0, $public_end);
define("WWW_ROOT", $doc_root);

require_once('functions.php');
require_once('database.php');
require_once('query_functions.php');
require_once('validation_functions.php');

$db = db_connect();
$errors = [];

//for search.php
//require_once('../private/SearchService.php');
//$searchService = new SearchService;
?>
