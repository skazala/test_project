<?php
class User {
    public $name;
    public $surname;
    public $email;
    public $address;
    public $phone;
    public $date;
}
?>