<?php $cards_set = get_all_cards(); ?>
<table>
  	<tr>
      <th>Number</th>
      <th>Type</th>
  	</tr>
    <?php while($card = mysqli_fetch_assoc($cards_set)) { ?>
        <tr>
          <td><?php echo htmlspecialchars($card['number']); ?></td>
          <td><?php echo htmlspecialchars($card['type']); ?></td>
    	</tr>
    <?php } ?>
</table>
<?php mysqli_free_result($cards_set); ?>