<?php require_once(SHARED_PATH . '/header.php'); ?>

    <div id="contentarea">
      <div id="centerbar">
        <h2>Search anything you want here!</h2>
        <form class="form" action="<?php echo url_for('/search.php'); ?>" method="post">
        <div class="forma">
            <input type="radio" id="name" name="search_by" value="name" checked>
            <label for="name">Search customer by name</label><br />
            <input type="radio" id="surname" name="search_by" value="surname">
            <label for="surname">Search customer by surname</label><br />
            <input type="radio" id="card_number" name="search_by" value="card_number">
            <label for="card_number">Search customer by card number</label><br />
            <input type="text" name="search_text" value="" />
            <input type="submit" value="Search" />
        </div>
        </form><br />
    <?php if(is_post_request()): ?>
        <?php if(!$users): ?>
            <h2>Nothing found</h2>
        <?php else: ?>
            <?php foreach($users as $user): ?>
                <div>
                    <p>Name: <?= htmlspecialchars($user->name) ?></p>
                    <p>Surname: <?= htmlspecialchars($user->surname) ?></p>
                    <p>Email: <?= htmlspecialchars($user->email) ?></p>
                    <p>Address: <?= htmlspecialchars($user->address) ?></p>
                    <p>Phone number: <?= htmlspecialchars($user->phone) ?></p>
                    <p>Date of registration: <?= htmlspecialchars($user->date) ?></p>
                    <br />
                </div>
            <?php endforeach ?>
        <?php endif ?>
    <?php endif ?>    
        <br />
        <br />
      </div>
      
    </div>

<?php require_once(SHARED_PATH . '/footer.php'); ?>