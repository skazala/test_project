<?php $cards_set = get_all_customers(); ?>
<table>
  	<tr>
      <th>Name</th>
      <th>Surname</th>
      <th>Email</th>
      <th>Address</th>
      <th>Phone Number</th>
      <th>Date of registration</th>
  	</tr>
    <?php while($card = mysqli_fetch_assoc($cards_set)) { ?>
        <tr>
          <td><?php echo htmlspecialchars($card['name']); ?></td>
          <td><?php echo htmlspecialchars($card['surname']); ?></td>
          <td><?php echo htmlspecialchars($card['email']); ?></td>
          <td><?php echo htmlspecialchars($card['address']); ?></td>
          <td><?php echo htmlspecialchars($card['phone']); ?></td>
          <td><?php echo htmlspecialchars($card['date_of_registration']); ?></td>
    	  </tr>
    <?php } ?>
</table>
<?php mysqli_free_result($cards_set); ?>