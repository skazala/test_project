<?php $customers_set = get_top_10_customers(); ?>
<h2>Top10 buyers at Crazy shop</h2>
<table>
  	<tr>
      <th>Money Spent</th>
      <th>Name</th>
      <th>Surname</th>
  	</tr>
    <?php while($customer = mysqli_fetch_assoc($customers_set)) { ?>
        <tr>
          <td><?php echo htmlspecialchars($customer['money_spent']); ?></td>
          <td><?php echo htmlspecialchars($customer['name']); ?></td>
          <td><?php echo htmlspecialchars($customer['surname']); ?></td>
    	  </tr>
    <?php } ?>
</table>
<?php mysqli_free_result($customers_set); ?>