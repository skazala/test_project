<?php

  function get_new_customer_id() {
    global $db;

    $sql = "SELECT id FROM customers ";
    $sql .= "ORDER BY id DESC ";
    $sql .= "LIMIT 1";
    $result = mysqli_query($db, $sql);
    confirm_result_set($result);
    $row = mysqli_fetch_row($result);
    mysqli_free_result($result);
    $id = $row[0];
    return $id;
  }

  function get_last_card_number() {
      global $db;

      $sql = "SELECT MAX(number) FROM loyalty_cards ";
      $sql .= "LIMIT 1";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      $row = mysqli_fetch_row($result);
      mysqli_free_result($result);
      $card_number = $row[0] ?? 1000;
      return $card_number;
  }

  function insert_loyalty_card($type) {
      global $db;

      $customer_id = get_new_customer_id();
      $number = (int)get_last_card_number() + 1;

      $sql = "INSERT INTO loyalty_cards ";
      $sql .= "(number, type, customer_id) ";
      $sql .= "VALUES (";
      $sql .= "'" . db_escape($db, $number) . "', ";
      $sql .= "'" . db_escape($db, $type) . "', ";
      $sql .= "'" . db_escape($db, $customer_id) . "'";
      $sql .= ")";
      $result = mysqli_query($db, $sql);
        if ($result) {
          return true;
        } else {
          //INSERT failed
          echo mysqli_error($db);
          db_disconnect($db);
          exit;
        }
  }    

    function validate_customer($customer) {
        // name
        if(is_blank($customer['name'])) {
          $errors[] = "Name cannot be blank.";
        } elseif(!has_length($customer['name'], ['min' => 2, 'max' => 255])) {
          $errors[] = "First name must be between 2 and 255 characters.";
        }       
        // surname
        if(is_blank($customer['surname'])) {
          $errors[] = "Surname cannot be blank.";
        } elseif(!has_length($customer['surname'], ['min' => 2, 'max' => 255])) {
          $errors[] = "Surname must be between 2 and 255 characters.";
        }   
        // e-mail
        if(is_blank($customer['email'])) {
          $errors[] = "E-mail cannot be blank.";
        } elseif (!has_valid_email_format($customer['email'])) {
          $errors[] = "Use correct e-mail.";
        }    
        // address
        if(is_blank($customer['address'])) {
          $errors[] = "Address cannot be blank.";
        }    
        // phone
        if(is_blank($customer['phone'])) {
            $errors[] = "Phone cannot be blank.";
          } elseif ($customer['phone'][0] !== '+'){
            //begins not with +
            $errors[] = "Phone must start with +.";
          } 
        if (preg_match('/[A-Za-z]/', $customer['phone'])) {
            $errors[] = "Phone must contain only numbers.";
          } 
        return $errors;        
    }
    
    function insert_customer($customer) {
        global $db;
    
        $errors = validate_customer($customer);
        if (!empty($errors)) {
          return $errors;
        }
    
        $sql = "INSERT INTO customers ";
        $sql .= "(name, surname, email, address, phone, date_of_registration) ";
        $sql .= "VALUES (";
        $sql .= "'" . db_escape($db, $customer['name']) . "', ";
        $sql .= "'" . db_escape($db, $customer['surname']) . "', ";
        $sql .= "'" . db_escape($db, $customer['email']) . "', ";
        $sql .= "'" . db_escape($db, $customer['address']) . "', ";
        $sql .= "'" . db_escape($db, $customer['phone']) . "', ";
        $sql .= "'" . db_escape($db, date('Y-m-d')) . "'";
        $sql .= ")";
        $result = mysqli_query($db, $sql);
        if ($result) {
          insert_loyalty_card($customer['card_type']);
          return true;         
        } else {
          //INSERT failed
          echo mysqli_error($db);
          db_disconnect($db);
          exit;
        }
    }
  
    function get_all_cards() {
      global $db;

      $sql = "SELECT number, type FROM loyalty_cards ";
      $sql .= "ORDER BY number ASC";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      return $result;  
    }

    function count_cards() {
      global $db;

      $sql = "SELECT COUNT(*) FROM loyalty_cards";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      $row = mysqli_fetch_row($result);
      mysqli_free_result($result);
      $count = $row[0]; 
      return $count;  
    }

    function get_all_customers() {
      global $db;

      $sql = "SELECT * FROM customers ";
      $sql .= "ORDER BY name ASC";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      return $result;  
    }

    function count_customers() {
      global $db;

      $sql = "SELECT COUNT(*) FROM customers";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      $row = mysqli_fetch_row($result);
      mysqli_free_result($result);
      $count = $row[0]; 
      return $count;  
    }

    function get_customers_by_name($name) {
      global $db;

      $sql = "SELECT * FROM customers ";
      $sql .= "WHERE name ='" . db_escape($db, $name) . "' ";
      $sql .= "ORDER BY surname ASC";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      return $result;  
    }
    
    function get_customers_by_surname($surname) {
      global $db;

      $sql = "SELECT * FROM customers ";
      $sql .= "WHERE surname ='" . db_escape($db, $surname) . "' ";
      $sql .= "ORDER BY name ASC";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      return $result;  
    }
    
    function get_customer_id_by_card_number($card_number) {
      global $db;

      $sql = "SELECT customer_id FROM loyalty_cards ";
      $sql .= "WHERE number ='" . db_escape($db, $card_number) . "' ";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      $row = mysqli_fetch_row($result);
      mysqli_free_result($result);
      $id = $row[0] ?? '';  
      return $id;
    }

    function get_customer_by_card_number($card_number) {
      global $db;
      
      $id = get_customer_id_by_card_number($card_number);
      $sql = "SELECT * FROM customers ";
      $sql .= "WHERE id ='" . db_escape($db, $id) . "' ";
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      return $result;  
    }  

    function get_top_10_customers() {
      global $db;

      $sql = "SELECT SUM(total_price) AS 'money_spent', customers.name AS 'name', customers.surname AS 'surname'";
      $sql .= "FROM purchases "; 
      $sql .= "INNER JOIN customers "; 
      $sql .= "ON purchases.customer_id = customers.id ";
      $sql .= "GROUP BY purchases.customer_id ORDER BY 1 DESC LIMIT 10";
      
      $result = mysqli_query($db, $sql);
      confirm_result_set($result);
      return $result; 
    }
?>