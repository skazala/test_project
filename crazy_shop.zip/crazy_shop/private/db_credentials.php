<?php
  define("DB_SERVER", "localhost");
  define("DB_USER", "Juliajulia");
  define("DB_PASS", "dlyachteniya");
  define("DB_NAME", "newshop");
?>