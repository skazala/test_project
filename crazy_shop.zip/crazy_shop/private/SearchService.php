<?php
//Service for handling search requests
class SearchService {
    private $users = [];

    public function byName($name){
        $set = get_customers_by_name($name);
        //$c = new User;
        while ($user = mysqli_fetch_assoc($set)) {
            $c = new User;
            $c->name = $user['name'];
            $c->surname = $user['surname'];
            $c->email = $user['email'];
            $c->address = $user['address'];
            $c->phone = $user['phone'];
            $c->date = $user['date_of_registration'];
            $users[] = $c;
        }
        mysqli_free_result($set);
        return $users ?? '';
    }

    public function bySurname($surname){
        $set = get_customers_by_surname($surname);
        while ($user = mysqli_fetch_assoc($set)) {
            $c = new User;
            $c->name = $user['name'];
            $c->surname = $user['surname'];
            $c->email = $user['email'];
            $c->address = $user['address'];
            $c->phone = $user['phone'];
            $c->date = $user['date_of_registration'];
            $users[] = $c;
        }
        mysqli_free_result($set);
        return $users ?? '';
    }

    public function byCardNumber($card_number){
        $set = get_customer_by_card_number($card_number);
        while ($user = mysqli_fetch_assoc($set)) {
            $c = new User;
            $c->name = $user['name'];
            $c->surname = $user['surname'];
            $c->email = $user['email'];
            $c->address = $user['address'];
            $c->phone = $user['phone'];
            $c->date = $user['date_of_registration'];
            $users[] = $c;
        }
        mysqli_free_result($set);
        return $users ?? '';
    }
}
?>