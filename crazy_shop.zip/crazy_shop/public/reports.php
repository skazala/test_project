<?php require_once('../private/initialize.php'); ?>

<?php require_once(SHARED_PATH . '/header.php'); ?>
 
<div id="contentarea">
  <div id="centerbar">
    <h2>Get almost any report you need rigth here!</h2>
    
    <form class="form" action="" method="post">
    <div class="forma">
        Choose a topic:
        <br />
        <select name="topic">
            <option value="cards">Loyalty cards</option>
            <option value="customers">Customers</option>
            <option value="topten">Top10 customers</option> 
        </select>
    </div>
    <div>
        <br />
        <input type="submit" value="Create a report" />
    </div>
    <br />
    </form>
    <?php //if post_request than do 
      if (is_post_request()) {
        if($_POST['topic'] == 'cards') {
            $count = count_cards();//show cards table
            echo ('<h2>There are ' . $count . ' loyalty cards.</h2>');
            require_once(VIEW_PATH . '/allcards.php');
        }
        if($_POST['topic'] == 'customers') {
            $count = count_customers();//show customers table
            echo ('<h2>There are ' . $count . ' customers in Crazy shop.</h2>');
            require_once(VIEW_PATH . '/allcustomers.php');
        }
        if($_POST['topic'] == 'topten') {
          require_once(VIEW_PATH . '/top10.php');
        }
      }
?>
  </div>      
</div>

<?php require_once(SHARED_PATH . '/footer.php'); ?>