<?php require_once('../private/initialize.php'); ?>

<?php require_once('../private/bootstrap.php'); ?>

<?php 
if(is_post_request()) {
  switch ($_POST['search_by']) {
    case 'name':
      $users = $searchService->byName($_POST['search_text']);
      break;
    case 'surname':
      $users = $searchService->bySurname($_POST['search_text']);
      break;
    case 'card_number':
      $users = $searchService->byCardNumber($_POST['search_text']);
      break;
  }
} 
?>
<?php require_once(VIEW_PATH . '/table.php'); ?>
