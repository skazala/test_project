<?php require_once('../private/initialize.php'); ?>
<?php require_once(SHARED_PATH . '/header.php'); ?>


<?php 
  if(is_post_request()) {
    $customer = [];
    $customer['name'] = $_POST['name'] ?? '';
    $customer['surname'] = $_POST['surname'] ?? '';
    $customer['email'] = $_POST['email'] ?? '';
    $customer['address'] = $_POST['address'] ?? '';
    $customer['phone'] = $_POST['phone'] ?? '';
    $customer['card_type'] = $_POST['card_type'] ?? '';
    
    $result = insert_customer($customer);

    if ($result === true) {
      header("Location: " . url_for('registration.php?=OK'));
      exit();
    } else {
      $errors = $result;
    }
  } else {
    //display blank form
    $customer = [];
    $customer['name'] = '';
    $customer['surname'] = '';
    $customer['email'] = '';
    $customer['address'] = '';
    $customer['phone'] = '';
    $customer['card_type'] = '';
  } 
?>

    <div id="contentarea">
      <div id="centerbar">
        <h2>Register a new customer here!</h2>        
        <br />
        <?php echo display_errors($errors); ?>

        <form class="form" action="<?php echo url_for('/registration.php'); ?>" method="post">
          <div class="forma">Name:
            <br /><input type="text" name="name" value="<?php echo htmlspecialchars($customer['name']); ?>" />
            <br />Surname:
            <br /><input type="text" name="surname" value="<?php echo htmlspecialchars($customer['surname']); ?>" />
            <br />E-mail:
            <br /><input type="email" name="email" value="<?php echo htmlspecialchars($customer['email']); ?>" />
            <br />Address:
            <br /><input type="text" name="address" value="<?php echo htmlspecialchars($customer['address']); ?>" />
            <br />Phone number:
            <br /><input type="text" name="phone" value="<?php echo htmlspecialchars($customer['phone']); ?>" placeholder="+1234567890"/>
            <br />Choose loyalty card type:
            <br /><select name="card_type">
                    
                    <option value="virtual" <?php if ($customer['card_type'] == 'virtual') {echo 'selected';} ?>>Virtual</option>
                    <option value="plastic" <?php if ($customer['card_type'] == 'plastic') {echo 'selected';} ?>>Plastic</option>
                  </select>
          </div>
          <div>
            <br />
              <input type="submit" value="Register a new customer" />
          </div>
        </form>
        
        <br />
      </div>
      
    </div>
    
<?php require_once(SHARED_PATH . '/footer.php'); ?>