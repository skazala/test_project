<?php require_once('../private/initialize.php'); ?>
<?php require_once(SHARED_PATH . '/header.php'); ?>
    <div id="contentarea">
      <div id="leftbar">
        <h2>Hello!</h2>
        <br />
        <h2>Feel free to browse through the Crazy shop.</h2>
        <br />
        <p>Links in the upper rigth corner can bring you to the
          registration page, the search page and the reports page. 
        </p>
        <br />
        <br />
      </div>
      <div id="rightbar">
        <h2>latest news</h2>
        <p><span class="orangetext">25/03/2022</span><br />
          The Crazy shop was born. <br />
          <br />
          <span class="orangetext">26/03/2022</span><br />
          New incredible opportunities are here. <br />
          <br />
          <span class="orangetext">27/03/2022</span><br />
          You can even buy water without a glass! </p>
      </div>
    </div>
<?php require_once(SHARED_PATH . '/footer.php'); ?>